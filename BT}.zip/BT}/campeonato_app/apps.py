from django.apps import AppConfig


class CampeonatoAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'campeonato_app'
